# -*- coding: utf-8 -*-
# SpaceClaim IronPython Script for Geometry Extraction
import json
import os
import clr
clr.AddReference("System.Web.Extensions")
from System.Web.Script.Serialization import JavaScriptSerializer

# === Configuration ===
# OUTPUT_PATH will be set dynamically or use a default
output_dir = r"C:\Temp\SCDM_Export" # Default, should be passed from caller
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

output_file = os.path.join(output_dir, "geometry_data.json")

def get_face_data(face):
    geometry = face.Geometry
    data = {
        "id": face.Id,
        "type": str(geometry.Shape),
        "area": face.Area,
        "box": {
            "min": [face.Range.Min.X, face.Range.Min.Y, face.Range.Min.Z],
            "max": [face.Range.Max.X, face.Range.Max.Y, face.Range.Max.Z]
        }
    }
    
    # Specific geometry info
    if str(geometry.Shape) == "Cylinder":
        data["radius"] = geometry.Radius
        data["axis"] = [geometry.Frame.Axis.Direction.X, geometry.Frame.Axis.Direction.Y, geometry.Frame.Axis.Direction.Z]
        data["origin"] = [geometry.Frame.Axis.Origin.X, geometry.Frame.Axis.Origin.Y, geometry.Frame.Axis.Origin.Z]
    elif str(geometry.Shape) == "Plane":
        data["normal"] = [geometry.Frame.Axis.Direction.X, geometry.Frame.Axis.Direction.Y, geometry.Frame.Axis.Direction.Z]
        data["origin"] = [geometry.Frame.Axis.Origin.X, geometry.Frame.Axis.Origin.Y, geometry.Frame.Axis.Origin.Z]
        
    return data

def extract_geometry():
    all_bodies_data = []
    
    bodies = GetRootPart().GetBodies()
    for i, body in enumerate(bodies):
        body_data = {
            "body_index": i,
            "body_name": body.Name,
            "volume": body.Volume,
            "faces": [],
            "adjacency": []
        }
        
        # Extract Face Data
        faces = body.Faces
        face_map = {} # To store index mapping
        for j, face in enumerate(faces):
            f_data = get_face_data(face)
            f_data["index"] = j
            body_data["faces"].append(f_data)
            face_map[face] = j
            
        # Extract Adjacency (Faces sharing an edge)
        edges = body.Edges
        for edge in edges:
            adj_faces = edge.Faces
            if adj_faces.Count == 2:
                idx1 = face_map.get(adj_faces[0])
                idx2 = face_map.get(adj_faces[1])
                if idx1 is not None and idx2 is not None:
                    body_data["adjacency"].append([idx1, idx2])
                    
        all_bodies_data.append(body_data)
        
    return all_bodies_data

# Main Execution
try:
    data = extract_geometry()
    
    # In IronPython 2.7, we use JavaScriptSerializer for JSON export if possible, 
    # or just a simple custom serializer if it's not available.
    # Here we'll use a simple approach for compatibility.
    
    serializer = JavaScriptSerializer()
    json_text = serializer.Serialize(data)
    
    with open(output_file, "w") as f:
        f.write(json_text)
        
    print("Extraction successful: " + output_file)
except Exception as e:
    print("Error during extraction: " + str(e))
