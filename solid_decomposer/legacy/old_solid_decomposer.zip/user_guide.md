# Solid Decomposer 사용자 가이드 (Windows 11 / SpaceClaim 환경)

본 도구는 SpaceClaim에서 복잡한 솔리드 형상을 메싱하기 좋은 상태로 자동 분할하기 위한 파이프라인입니다.

## 📋 폴더 구조 (단계별 흐름)
- **01_extractor**: SpaceClaim에서 데이터를 추출하는 스크립트가 들어있습니다.
- **02_planner**: 추출된 데이터를 분석하고 분할 전략을 세우는 핵심 엔진입니다.
- **03_generator**: 수립된 계획을 다시 SpaceClaim 스크립트로 변환합니다.
- **04_scripts**: 최종적으로 생성된 실행 스크립트들이 저장되는 곳입니다.
- **data**: 추출된 중간 데이터(`.json`)가 저장되는 곳입니다.

## 🚀 단계별 실행 방법

### Step 1: 데이터 추출 (SCDM 내부)
1. SpaceClaim을 실행하고 대상 CAD 파일을 엽니다.
2. 스크립트 창(Scripting)을 열고 `01_extractor/scdm_extractor.py`의 내용을 복사해서 붙여넣습니다.
3. 실행(Run) 버튼을 누르면 `data/geometry_data.json`이 생성됩니다.

### Step 2: 분할 계획 수립 (Python 외부)
1. 터미널(CMD/PowerShell)에서 다음 명령을 실행합니다.
   ```bash
   # 사용법: python main_run.py [기기이름]
   python main_run.py VALVE_01
   ```
2. 플래너가 데이터를 분석하고 `04_scripts/VALVE_01_scdm_script.py` 파일을 생성합니다.
3. 만약 형상이 복잡하면 AI 조언(Advice)이 화면에 출력됩니다.

### Step 3: 실제 분할 실행 (SCDM 내부)
1. 다시 SpaceClaim으로 돌아가서, 새 스크립트 창을 엽니다.
2. `04_scripts/VALVE_01_scdm_script.py` 파일 내용을 복사해서 붙여넣습니다.
3. 실행하면 솔리드가 잘리고 Named Selection이 자동으로 생성됩니다.

## 💡 주요 기능
- **O-grid / H-grid / Sector**: 기본 메싱 전략 자동 적용
- **Junction / Elbow**: 복잡한 파이프 접합부 및 꺾임 구간 자동 인식
- **Mesh Recommendation**: Named Selection 이름에 적정 메쉬 사이즈 정보 포함 (Beta)
- **Auto-merge Safety**: 너무 얇은 분할이 발생할 경우 경고 알림 (Beta)
