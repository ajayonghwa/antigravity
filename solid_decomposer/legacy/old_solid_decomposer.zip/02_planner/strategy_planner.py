import json
import numpy as np

class StrategyPlanner:
    def __init__(self, sub_device_name="DEVICE", options=None):
        self.sub_device_name = sub_device_name
        self.options = options or {
            "mesh_recommendation": True,
            "auto_merge_safety": True,
            "symmetry_check": True
        }

    def analyze_body(self, body_data):
        faces = body_data.get("faces", [])
        cylinders = [f for f in faces if f["type"] == "Cylinder"]
        planes = [f for f in faces if f["type"] == "Plane"]
        bends = [f for f in faces if f["type"] == "Toroidal"]
        plans = []

        # [Beta] Symmetry Check (단순 볼륨 기반 가이드)
        if self.options.get("symmetry_check"):
            if body_data.get("volume", 0) > 0 and body_data.get("volume", 0) % 2 == 0:
                # 대칭성 가능성 가이드 (로그용)
                pass

        # 1. 접합부 분할 (Junction Splitting)
        if len(cylinders) >= 2:
            main_axis = [0, 0, 1] # 기준축
            side_holes = [c for c in cylinders if not np.isclose(np.abs(c["axis"]), main_axis).all()]
            if side_holes:
                for hole in side_holes:
                    plans.append(self._generate_ogrid_plan(body_data, hole, "JunctionHole"))
                return "JUNCTION", self._apply_beta_options(plans, body_data)

        # 2. 꺾임 관 분할 (Elbow Pipe)
        if bends:
            for bend in bends:
                z_at = bend.get("origin", [0,0,0])[2]
                plans.append(self._generate_axial_split_plan(body_data, z_at))
            return "ELBOW_PIPE", self._apply_beta_options(plans, body_data)

        # 3. 하이브리드 분할 (OH Hybrid)
        if cylinders and len(planes) >= 6:
            for cyl in cylinders:
                plans.append(self._generate_ogrid_plan(body_data, cyl, "HybridHole"))
            plans.extend(self._generate_hgrid_plan(body_data, planes))
            return "OH_HYBRID", self._apply_beta_options(plans, body_data)

        # 4. 축 방향 분할 (Complex/Axial)
        if cylinders:
            main_axis = [0, 0, 1]
            main_cylinders = [c for c in cylinders if np.isclose(np.abs(c["axis"]), main_axis).all()]
            radii = set([round(c["radius"], 2) for c in main_cylinders])
            if len(radii) > 1:
                z_splits = set()
                for cyl in main_cylinders:
                    z_splits.add(cyl["box"]["min"][2])
                    z_splits.add(cyl["box"]["max"][2])
                sorted_z = sorted(list(z_splits))
                for z in sorted_z[1:-1]:
                    plans.append(self._generate_axial_split_plan(body_data, z))
                return "AXIAL", self._apply_beta_options(plans, body_data)

            # 5. 일반 O-grid
            for i, cyl in enumerate(cylinders):
                plans.append(self._generate_ogrid_plan(body_data, cyl, f"Hole{i}"))
            return "OGRID", self._apply_beta_options(plans, body_data)

        # 6. 일반 H-grid
        if len(planes) >= 6:
            plans.extend(self._generate_hgrid_plan(body_data, planes))
            return "HGRID", self._apply_beta_options(plans, body_data)

        return "COMPLEX", None

    def _apply_beta_options(self, plans, body_data):
        """
        베타 옵션(메쉬 추천, 안전성 검사)을 계획에 적용합니다.
        """
        for plan in plans:
            # 1. 메쉬 크기 추천 (Beta)
            if self.options.get("mesh_recommendation"):
                recommended_size = 2.0 
                if "core_offset" in plan:
                    recommended_size = round(plan["core_offset"] / 3.0, 1)
                
                # NS 이름에 추천 사이즈 추가
                for key in plan["named_selections"]:
                    plan["named_selections"][key] += f"_SIZE_{recommended_size}mm"

            # 2. 자동 병합 안전성 (Beta)
            if self.options.get("auto_merge_safety"):
                if plan.get("core_offset", 10) < 0.5:
                    plan["warning"] = "Too small split detected. Consider merging."

        return plans

    def _generate_ogrid_plan(self, body_data, cylinder_face, hole_id="Core"):
        origin = cylinder_face["origin"]
        axis = cylinder_face["axis"]
        radius = cylinder_face.get("radius", 1.0)
        core_offset = radius * 0.6
        
        plan = {
            "strategy": "OGRID",
            "body_name": body_data["body_name"],
            "hole_id": hole_id,
            "center": origin,
            "axis": axis,
            "core_offset": core_offset,
            "named_selections": {
                "core": f"{self.sub_device_name}_{hole_id}_OGRID_CORE",
                "outer": f"{self.sub_device_name}_{hole_id}_OGRID_OUTER"
            }
        }
        return plan

    def _generate_hgrid_plan(self, body_data, planes):
        min_pt = np.min([f["box"]["min"] for f in planes], axis=0)
        max_pt = np.max([f["box"]["max"] for f in planes], axis=0)
        size = max_pt - min_pt
        long_axis_idx = np.argmax(size)
        split_coord = (min_pt[long_axis_idx] + max_pt[long_axis_idx]) / 2.0
        origin = [(min_pt[i] + max_pt[i]) / 2.0 for i in range(3)]
        origin[long_axis_idx] = split_coord
        normal = [0, 0, 0]
        normal[long_axis_idx] = 1
        
        plan = {
            "strategy": "HGRID",
            "body_name": body_data["body_name"],
            "split_plane": {
                "origin": [float(x) for x in origin],
                "normal": [int(x) for x in normal]
            },
            "named_selections": {
                "part_a": f"{self.sub_device_name}_HGRID_A",
                "part_b": f"{self.sub_device_name}_HGRID_B"
            }
        }
        return [plan]

    def _generate_axial_split_plan(self, body_data, z_coord):
        plan = {
            "strategy": "AXIAL",
            "body_name": body_data["body_name"],
            "split_plane": {
                "origin": [0.0, 0.0, float(z_coord)],
                "normal": [0, 0, 1]
            },
            "named_selections": {
                "part_upper": f"{self.sub_device_name}_AXIAL_Z{z_coord}_UP",
                "part_lower": f"{self.sub_device_name}_AXIAL_Z{z_coord}_LOW"
            }
        }
        return plan

    def _generate_sector_split_plan(self, body_data, main_axis):
        plans = []
        plans.append({
            "strategy": "SECTOR",
            "body_name": body_data["body_name"],
            "split_plane": {"origin": [0.0, 0.0, 0.0], "normal": [0, 1, 0]},
            "named_selections": {"part_a": f"{self.sub_device_name}_SEC_XZ_A", "part_b": f"{self.sub_device_name}_SEC_XZ_B"}
        })
        plans.append({
            "strategy": "SECTOR",
            "body_name": body_data["body_name"],
            "split_plane": {"origin": [0.0, 0.0, 0.0], "normal": [1, 0, 0]},
            "named_selections": {"part_a": f"{self.sub_device_name}_SEC_YZ_A", "part_b": f"{self.sub_device_name}_SEC_YZ_B"}
        })
        return plans

    def get_ai_advice(self, body_data):
        return "해당 형상은 분기점이 복잡합니다. 메인 바디와 연결된 파이프의 접합부를 기준으로 평면 분할을 먼저 시도하세요."
