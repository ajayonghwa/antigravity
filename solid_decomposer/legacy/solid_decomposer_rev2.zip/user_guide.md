# 🚀 SpaceClaim Solid Decomposition 파이프라인 가이드

본 프로젝트는 Ansys 2024 R1 SpaceClaim(SCDM) 환경에서 복잡한 솔리드 형상을 자동으로 분석하고, Hex Meshing이 가능한 형태로 분할(Decomposition)하는 파이프라인입니다.

## 📂 프로젝트 구조
- `01_extractor/`: SCDM에서 기하학 정보를 추출하는 IronPython 스크립트
- `02_planner/`: 추출된 데이터를 분석하여 분할 전략을 세우는 Python 엔진
- `03_generator/`: 수립된 전략을 SCDM 실행 스크립트로 변환하는 생성기
- `04_scripts/`: 최종적으로 생성된 SCDM 실행 스크립트 저장 폴더
- `data/`: 추출된 JSON 데이터 저장 폴더

## ✨ 주요 기능 (V1.2 최신 버전)
1. **꺾임 관(Bent Pipe) 자동 대응**: 축이 서로 다른 파이프 형상을 감지하여 최적의 횡단 분할(Transverse Cut)을 수행합니다.
2. **중복 컴포넌트 완벽 식별**: `GetFullName` 방식을 도입하여 동일한 이름의 바디가 여러 컴포넌트에 있어도 충돌 없이 처리합니다.
3. **지능형 Named Selection**: 분할 후 조각들의 부피를 계산하여 `CORE`, `OUTER` 등을 자동 구분하고 메쉬 사이즈 추천값(Beta)을 이름에 포함합니다.
4. **fragment 추적 자르기**: 솔리드가 잘리면서 이름이 변형되어도(예: `Body (1)`) 끝까지 추적하여 모든 분할 계획을 완수합니다.
5. **안전한 자원 관리**: 자르기에 사용된 임시 서피스와 평면을 실행 후 자동으로 삭제하여 CAD 모델을 청결하게 유지합니다.

## 🚀 단계별 실행 방법

### Step 1: 데이터 추출 (SCDM 내부)
1. SpaceClaim을 실행하고 대상 CAD 파일을 엽니다.
2. 스크립트 창(Scripting)을 열고 `01_extractor/scdm_extractor.py`의 내용을 복사해서 붙여넣습니다.
3. 실행(Run) 버튼을 누르면 `data/geometry_data.json`이 생성됩니다.
   - *팁: 바디 이름이 중복되어도 전체 경로로 구분되니 안심하고 실행하세요.*

### Step 2: 분할 계획 수립 (Python 외부)
1. 터미널(CMD/PowerShell)에서 다음 명령을 실행합니다.
   ```bash
   # 사용법: python main_run.py [기기이름]
   python main_run.py VALVE_01
   ```
2. 플래너가 데이터를 분석하고 `04_scripts/VALVE_01_scdm_script.py` 파일을 생성합니다.
   - *참고: 형상이 꺾인 관이라면 자동으로 `Strategy: BENT_PIPE`가 적용됩니다.*

### Step 3: 실제 분할 실행 (SCDM 내부)
1. 다시 SpaceClaim으로 돌아가서, **새 스크립트 창**을 엽니다.
2. `04_scripts/VALVE_01_scdm_script.py` 파일 내용을 복사해서 붙여넣습니다.
3. 실행하면:
   - 솔리드가 계획대로 정확히 분할됩니다.
   - 각 조각에 맞는 **Named Selection(그룹)**이 생성됩니다.
   - Shared Topology가 자동으로 적용되어 Conformal Mesh 준비가 완료됩니다.

---
> [!TIP]
> **로컬 LLM 조언 기능 (Beta)**: 자동 분할이 불가능한 복잡한 형상의 경우, 터미널에 출력되는 AI Advice를 참고하여 수동 분할을 진행하세요. (Ollama 연동 가능)
