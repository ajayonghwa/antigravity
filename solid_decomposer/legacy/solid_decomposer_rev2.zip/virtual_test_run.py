import os
import sys
import json

# 프로젝트 루트를 경로에 추가
sys.path.append(os.getcwd())

from extractor.extract_manager import ExtractManager
from planner.strategy_planner import StrategyPlanner
from generator.scdm_generator import SCDMGenerator

def virtual_test():
    print("=== Solid Decomposer Integrated Virtual Test ===")
    
    # 1. 환경 설정
    project_root = os.path.join(os.getcwd(), "solid_decomposer")
    manager = ExtractManager(project_root)
    planner = StrategyPlanner(sub_device_name="VALVE01")
    generator = SCDMGenerator(project_root)
    
    # 2. Mock 데이터 로드
    mock_json = "geometry_data_hybrid.json"
    data = manager.load_geometry_data(mock_json)
    
    if not data:
        print("Failed to load mock data.")
        return

    # 3. 플래닝 및 계획 수집
    all_plans = []
    for body in data:
        print(f"\n[Analyzing Body: {body['body_name']}]")
        strategy, plans = planner.analyze_body(body)
        
        print(f" - Strategy detected: {strategy}")
        if strategy in ["OGRID", "HGRID", "AXIAL", "SECTOR", "COMPLEX_CYLINDER", "ELBOW_PIPE", "JUNCTION", "OH_HYBRID"]:
            for p in plans:
                strat = p["strategy"]
                if strat == "OGRID":
                    print(f"   * O-grid (Hole: {p['hole_id']}, Offset: {p['core_offset']:.2f})")
                elif strat in ["AXIAL", "SECTOR", "HGRID", "JUNCTION"]:
                    print(f"   * Plane Split ({strat}): Origin {p['split_plane']['origin']}, Normal {p['split_plane']['normal']}")
                
                # 베타 옵션 정보 출력
                for ns_key, ns_name in p["named_selections"].items():
                    print(f"     > NS: {ns_name}")
                if "warning" in p:
                    print(f"     [!] Warning: {p['warning']}")
                
                all_plans.append(p)
        elif strategy == "COMPLEX":
            advice = planner.get_ai_advice(body)
            print(f" - AI Advice: {advice}")

    # 4. 최종 SCDM 스크립트 생성
    if all_plans:
        print(f"\n[Generating SCDM Script]")
        output_script = generator.generate_script(all_plans)
        print(f" - Script generated: {output_script}")
        
        if os.path.exists(output_script):
            print(" - Success: Final script is ready for SpaceClaim.")
    else:
        print("\nNo decomposition plans generated.")

    print("\n=== Integrated Virtual Test Completed ===")

if __name__ == "__main__":
    virtual_test()
