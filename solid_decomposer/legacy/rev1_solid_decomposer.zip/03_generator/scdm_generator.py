import os

class SCDMGenerator:
    def __init__(self, project_root):
        self.project_root = project_root
        self.script_template = """
# -*- coding: utf-8 -*-
# Auto-generated SpaceClaim Script for Solid Decomposition

def apply_ogrid(body_name, center_list, axis_list, core_offset, ns_names):
    # 1. 대상 바디 찾기 (모든 컴포넌트 탐색)
    bodies = GetRootPart().GetAllBodies()
    target_body = None
    for b in bodies:
        if b.Name == body_name:
            target_body = b
            break
    
    if not target_body:
        print("Body not found: " + body_name)
        return

    # 2. 실린더 컷팅 평면/축 설정
    origin = Point.Create(center_list[0], center_list[1], center_list[2])
    direction = Direction.Create(axis_list[0], axis_list[1], axis_list[2])
    frame = Frame.Create(origin, direction)
    
    # 3. 실린더형 툴 표면 생성 및 자르기
    print("O-grid Splitting for: " + body_name)
    try:
        cylinder = Cylinder.Create(frame, core_offset)
        SplitBody.Execute(target_body, cylinder)
    except Exception as e:
        print("Failed to apply O-grid split: " + str(e))
    
    # 4. Shared Topology 설정
    GetRootPart().SharedTopology = SharedTopology.Share

def apply_hgrid(body_name, origin_list, normal_list, ns_names):
    # 1. 대상 바디 찾기
    bodies = GetRootPart().GetAllBodies()
    target_body = None
    for b in bodies:
        if b.Name == body_name:
            target_body = b
            break
            
    if not target_body:
        print("Body not found: " + body_name)
        return

    # 2. 분할 평면 생성
    origin = Point.Create(origin_list[0], origin_list[1], origin_list[2])
    normal = Direction.Create(normal_list[0], normal_list[1], normal_list[2])
    plane = Plane.Create(origin, normal)
    
    # 3. 바디 분할 실행
    print("H-grid Plane Splitting for: " + body_name)
    try:
        SplitBody.Execute(target_body, plane)
    except Exception as e:
        print("Failed to apply H-grid split: " + str(e))

def finalize():
    print("All operations completed successfully.")

# --- Execution ---
{execution_calls}
finalize()
"""


    def generate_script(self, plan_list, output_name="final_scdm_script.py"):
        execution_calls = ""
        for plan in plan_list:
            if plan["strategy"] == "OGRID":
                call = f"apply_ogrid('{plan['body_name']}', {plan['center']}, {plan['axis']}, {plan['core_offset']}, {plan['named_selections']})\n"
                execution_calls += call
            elif plan["strategy"] in ["HGRID", "AXIAL", "SECTOR", "JUNCTION"]:
                split = plan["split_plane"]
                call = f"apply_hgrid('{plan['body_name']}', {split['origin']}, {split['normal']}, {plan['named_selections']})\n"
                execution_calls += call
        
        final_content = self.script_template.format(execution_calls=execution_calls)
        
        output_path = os.path.join(self.project_root, "04_scripts", output_name)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(final_content)
        
        return output_path

if __name__ == "__main__":
    # 테스트용 모의 계획
    mock_plan = [{
        "body_name": "Test_Cylinder",
        "strategy": "OGRID",
        "center": [0, 0, 0],
        "axis": [0, 0, 1],
        "core_offset": 3.0,
        "named_selections": {"core": "VALVE_OGRID_CORE", "outer": "VALVE_OGRID_OUTER"}
    }]
    
    gen = SCDMGenerator(os.getcwd())
    gen.generate_script(mock_plan)
    print("Script generated in scripts/final_scdm_script.py")
